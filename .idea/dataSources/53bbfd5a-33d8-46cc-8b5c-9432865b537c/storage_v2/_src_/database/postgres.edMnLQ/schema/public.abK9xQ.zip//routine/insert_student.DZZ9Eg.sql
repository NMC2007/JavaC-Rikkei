create procedure insert_student(IN name_in character varying, IN birthday_in date, IN sex_in boolean)
    language plpgsql
as
$$
    BEGIN
       insert into student(name, birthday, sex) values (name_in, birthday_in, sex_in);
    END
$$;

alter procedure insert_student(varchar, date, boolean) owner to postgres;

